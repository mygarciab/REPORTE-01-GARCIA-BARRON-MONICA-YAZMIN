#Usuarios registrados en la base de datos del sistema de Lifestore 

administradores=[
    ['administrador1', 'password1'],
    ['administrador2', '123456'],
    ['administrador3', '654321'], 
    ['administrador4', 'password123']]