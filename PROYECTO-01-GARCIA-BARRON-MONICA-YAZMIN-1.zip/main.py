#lifestore_products = [id_product, name, price, category, stock]
from lifestore_file import lifestore_products

#lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
from lifestore_file import lifestore_sales

#lifestore_searches = [id_search, id product]
from lifestore_file import lifestore_searches

#UsuariosLifestore=[usuario, password]
from UsuariosLifestore import administradores #Importa lista de usuarios registrados.

#Texto con encabezado que se muestra al iniciar la ejecución del programa.
print("""*******************************************************
-------------------------------------------------------
        
        S I S T E M A  D E  R O T A C I O N   
              D E   P R O D U C T O S

<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------
*******************************************************""")

username = input("Usuario: ")
password = input("Contraseña: ")

usuario_registrado = 0 #Variable para indicar si el usuario y password se encuentran en la base de datos.
intentos = 1 #Variable para contar los intentos de ingresar al sistema.

while usuario_registrado != 1 and intentos <= 2:  #Bucle while para login de usuario, permite 3 intentos.
  for administrador in administradores:
    if username == administrador[0] and password == administrador[1]:
      usuario_registrado = 1

  if usuario_registrado == 0: #Sentencia para cuando los datos ingresados del usuario son incorrectos de acuerdo a la base de datos.
    print("El usuario y/o contraseña son incorrectos.")
    username = input("Usuario: ")
    password = input("Contraseña: ")
    intentos += 1

if usuario_registrado == 1: #Sentencia para cuando los datos ingresados del usuario son correctos de acuerdo a la base de datos.
  print("""*******************************************************
-------------------------------------------------------
        
================= B I E N V E N I D O =================
           
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------
*******************************************************""")

  #Ventas Anuales con devolución
  #sales_dev=[id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
  sales_dev = []
  for sale_dev in lifestore_sales:
    if sale_dev[3][6:10] == "2020":
      sales_dev.append(sale_dev)
  
  
      

  #Ventas Anuales sin devoluciones
  #sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
  sales = []
  for sale in lifestore_sales:
    if sale[3][6:10] == "2020" and sale[4] == 0:
      sales.append(sale)



  #Contar las Ventas del 2020
  contador = 0
  ventas_productos = [] #ventas_productos[id_product, name, quantity of sales, price]
  for product in lifestore_products:
    for sale in sales:
      if product[0] == sale[1]:
        contador += 1
    if contador != 0:
      ventas_productos.append([product[0], product[1], contador, product[2]])
      contador = 0

  #Contar las Ventas con Devolución del 2020
  contadordev = 0
  ventas_productosd = [] #ventas_productosd[id_product, name, quantity of sales, price]
  for product in lifestore_products:
    for sale_dev in sales_dev:
      if product[0] == sale_dev[1]:
        contadordev += 1
    if contadordev != 0:
      ventas_productosd.append([product[0], product[1], contadordev, product[2]])
      contadordev = 0

    
  #Total de ingresos anuales 
  ingreso_anual = 0
  for venta_producto in ventas_productos:
    multiplica = float(venta_producto[2])*float(venta_producto[3])
    ingreso_anual = ingreso_anual + multiplica

  

  #Ventas Enero
  sales_enero = []
    
  for sale in sales:
    if sale[3][3:5] == "01":
      sales_enero.append(sale)

  #Contar las Ventas del 01/2020
  contadorE = 0
  ventas_productosE = []
  for product in lifestore_products:
    for sale_enero in sales_enero:
      if product[0] == sale_enero[1]:
        contadorE += 1
    if contadorE != 0:
      ventas_productosE.append([product[0], product[1], contadorE, product[2]])
      contadorE = 0
  
  #Total de ingresos Enero
  ingreso_enero = 0
  for venta_productoE in ventas_productosE:
    multiplicaE = float(venta_productoE[2])*float(venta_productoE[3])
    ingreso_enero = ingreso_enero + multiplicaE

  #Ventas Febrero
  sales_feb = []
  for sale in sales:
    if sale[3][3:5] == "02":
      sales_feb.append(sale)

  #Contar las Ventas del 02/2020
  contadorFeb = 0
  ventas_productosFeb = []
  for product in lifestore_products:
    for sale_feb in sales_feb:
      if product[0] == sale_feb[1]:
        contadorFeb += 1
    if contadorFeb != 0:
      ventas_productosFeb.append([product[0], product[1], contadorFeb, product[2]])
      contadorFeb = 0
  
  #Total de ingresos Febrero
  ingreso_febrero = 0
  for venta_productoFeb in ventas_productosFeb:
    multiplicaF = float(venta_productoFeb[2])*float(venta_productoFeb[3])
    ingreso_febrero = ingreso_febrero + multiplicaF

  #Ventas Marzo
  sales_mar = []
  for sale in sales:
    if sale[3][3:5] == "03":
      sales_mar.append(sale)

  #Contar las Ventas del 03/2020
  contadorMar = 0
  ventas_productosMar = []
  for product in lifestore_products:
    for sale_mar in sales_mar:
      if product[0] == sale_mar[1]:
        contadorMar += 1
    if contadorMar != 0:
      ventas_productosMar.append([product[0], product[1], contadorMar, product[2]])
      contadorMar = 0
  
  #Total de ingresos Marzo
  ingreso_marzo = 0
  for venta_productoMar in ventas_productosMar:
    multiplicaM = float(venta_productoMar[2])*float(venta_productoMar[3])
    ingreso_marzo = ingreso_marzo + multiplicaM

  #Ventas Abril
  sales_abr = []
  for sale in sales:
    if sale[3][3:5] == "04":
      sales_abr.append(sale)

  #Contar las Ventas del 04/2020
  contadorAbr = 0
  ventas_productosAbr = []
  for product in lifestore_products:
    for sale_abr in sales_abr:
      if product[0] == sale_abr[1]:
        contadorAbr += 1
    if contadorAbr != 0:
      ventas_productosAbr.append([product[0], product[1], contadorAbr, product[2]])
      contadorAbr = 0

  #Total de ingresos Abril
  ingreso_abril = 0
  for venta_productoAbr in ventas_productosAbr:
    multiplicaA = float(venta_productoAbr[2])*float(venta_productoAbr[3])
    ingreso_abril = ingreso_abril + multiplicaA

 #Ventas de Mayo
  sales_may = []
  for sale in sales:
    if sale[3][3:5] == "05":
      sales_may.append(sale)

  #Contar las Ventas del 05/2020
  contadorMay = 0
  ventas_productosMay = []
  for product in lifestore_products:
    for sale_may in sales_may:
      if product[0] == sale_may[1]:
        contadorMay += 1
    if contadorMay != 0:
      ventas_productosMay.append([product[0], product[1], contadorMay, product[2]])
      contadorMay = 0

  #Total de ingresos Mayo
  ingreso_mayo = 0
  for venta_productoMay in ventas_productosMay:
    multiplicaMa = float(venta_productoMay[2])*float(venta_productoMay[3])
    ingreso_mayo = ingreso_mayo + multiplicaMa
    
  #Ventas Junio
  sales_jun = []
  for sale in sales:
    if sale[3][3:5] == "06":
      sales_jun.append(sale)

  #Contar las Ventas del 06/2020
  contadorJun = 0
  ventas_productosJun = []
  for product in lifestore_products:
    for sale_jun in sales_jun:
      if product[0] == sale_jun[1]:
        contadorJun += 1
    if contadorJun != 0:
      ventas_productosJun.append([product[0], product[1], contadorJun, product[2]])
      contadorJun = 0
  
  #Total de ingresos Junio
  ingreso_junio = 0
  for venta_productoJun in ventas_productosJun:
    multiplicaJ = float(venta_productoJun[2])*float(venta_productoJun[3])
    ingreso_junio = ingreso_junio + multiplicaJ

  #Ventas Julio
  sales_jul = []
  for sale in sales:
    if sale[3][3:5] == "07":
      sales_jul.append(sale)

  #Contar las Ventas del 07/2020
  contadorJul = 0
  ventas_productosJul = []
  for product in lifestore_products:
    for sale_jul in sales_jul:
      if product[0] == sale_jul[1]:
        contadorJul += 1
    if contadorJul != 0:
      ventas_productosJul.append([product[0], product[1], contadorJul, product[2]])
      contadorJul = 0
  
  #Total de ingresos Julio
  ingreso_julio = 0
  for venta_productoJul in ventas_productosJul:
    multiplicaJu = float(venta_productoJul[2])*float(venta_productoJul[3])
    ingreso_julio = ingreso_julio + multiplicaJu

  #Ventas Agosto
  sales_ago = []
  for sale in sales:
    if sale[3][3:5] == "08":
      sales_ago.append(sale)

  #Contar las Ventas del 08/2020
  contadorAgo = 0
  ventas_productosAgo = []
  for product in lifestore_products:
    for sale_ago in sales_ago:
      if product[0] == sale_ago[1]:
        contadorAgo += 1
    if contadorAgo != 0:
      ventas_productosAgo.append([product[0], product[1], contadorAgo, product[2]])
      contadorAgo = 0

  #Total de ingresos Agosto
  ingreso_agosto = 0
  for venta_productoAgo in ventas_productosAgo:
    multiplicaAg = float(venta_productoAgo[2])*float(venta_productoAgo[3])
    ingreso_agosto = ingreso_agosto + multiplicaAg
  
  #Ventas Septiembre
  sales_sep = []
  for sale in sales:
    if sale[3][3:5] == "09":
      sales_sep.append(sale)

  #Contar las Ventas del 09/2020
  contadorSep = 0
  ventas_productosSep = []
  for product in lifestore_products:
    for sale_sep in sales_sep:
      if product[0] == sale_sep[1]:
        contadorSep += 1
    if contadorSep != 0:
      ventas_productosSep.append([product[0], product[1], contadorSep, product[2]])
      contadorSep = 0

  #Total de ingresos Septiembre
  ingreso_septiembre = 0
  for venta_productoSep in ventas_productosSep:
    multiplicaS = float(venta_productoSep[2])*float(venta_productoSep[3])
    ingreso_septiembre = ingreso_septiembre + multiplicaS
  
  #Ventas Octubre
  sales_oct = []
  for sale in sales:
    if sale[3][3:5] == "10":
      sales_oct.append(sale)

  #Contar las Ventas del 10/2020
  contadorOct = 0
  ventas_productosOct = []
  for product in lifestore_products:
    for sale_oct in sales_oct:
      if product[0] == sale_oct[1]:
        contadorOct += 1
    if contadorOct != 0:
      ventas_productosOct.append([product[0], product[1], contadorOct, product[2]])
      contadorOct = 0

  #Total de ingresos Octubre
  ingreso_octubre = 0
  for venta_productoOct in ventas_productosOct:
    multiplicaO = float(venta_productoOct[2])*float(venta_productoOct[3])
    ingreso_octubre = ingreso_octubre + multiplicaO

  #Ventas Noviembre
  sales_nov = []
  for sale in sales:
    if sale[3][3:5] == "11":
      sales_nov.append(sale)

  #Contar las Ventas del 11/2020
  contadorNov = 0
  ventas_productosNov = []
  for product in lifestore_products:
    for sale_nov in sales_nov:
      if product[0] == sale_nov[1]:
        contadorNov += 1
    if contadorNov != 0:
      ventas_productosNov.append([product[0], product[1], contadorNov, product[2]])
      contadorNov = 0

  #Total de ingresos Noviembre
  ingreso_noviembre = 0
  for venta_productoNov in ventas_productosNov:
    multiplicaN = float(venta_productoNov[2])*float(venta_productoNov[3])
    ingreso_noviembre = ingreso_noviembre + multiplicaN

  #Ventas Diciembre
  sales_dic = []
  for sale in sales:
    if sale[3][3:5] == "12":
      sales_dic.append(sale)

  #Contar las Ventas del 12/2020
  contadorDic = 0
  ventas_productosDic = []
  for product in lifestore_products:
    for sale_dic in sales_dic:
      if product[0] == sale_dic[1]:
        contadorDic += 1
    if contadorDic != 0:
      ventas_productosDic.append([product[0], product[1], contadorDic, product[2]])
      contadorDic = 0

  #Total de ingresos Diciembre
  ingreso_diciembre = 0
  for venta_productoDic in ventas_productosDic:
    multiplicaD = float(venta_productoDic[2])*float(venta_productoDic[3])
    ingreso_diciembre = ingreso_diciembre + multiplicaD

  #Búsquedas anuales
  contador_searches = 0
  busquedas = []
  longitud_products = len(lifestore_products)
  longitud_searches = len(lifestore_searches)
  for product in lifestore_products:
    for search in lifestore_searches:
      if product[0] == search[1]:
        contador_searches +=1
      elif contador_searches !=0:
        busquedas.append([product[1], contador_searches])
        contador_searches = 0
  if product[0] == longitud_products and contador_searches != 0:
      busquedas.append([product[1],contador_searches])

  opcion_del_menu_principal = "A"
  mostrar_menu_principal = "si"

  while mostrar_menu_principal == "si": #Bucle while del menú principal.
    print("""-------------------------------------------------------
          
======= M  E  N  U    P  R  I  N  C  I  P  A  L =======
            
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------
Productos más vendidos y productos rezagados......(A)
Productos por reseña en el servicio...............(B)
Total de ingresos y ventas promedio...............(C)
Salir del sistema.................................(D)""")
    opcion_del_menu_principal = input("""
Seleccione una opción del menú (A / B / C / D): """)
    if opcion_del_menu_principal == "A": #Sentencia para productos más vendidos y productos rezagados.
        opcion_del_menu_mas_vendidos_y_rezagados = "a"
        mostrar_menu_mas_vendidos_y_rezagados = "si"
        while mostrar_menu_mas_vendidos_y_rezagados == "si": #Bucle while del menú más vendidos y rezagados.
            print("""
-------------------------------------------------------
              
                    M  E  N  U    
    P R O D U C T O S  M Á S  V E N D I D O S 
    Y  P R O D U C T O S   R E Z A G A D O S 
                  
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------
Listado de productos con mayores ventas...........(a)
Listado de productos con mayores búsquedas........(b)
Listado por categoría con menores ventas .........(c)
Listado por categoría con menores búsquedas.......(d)
Regresar al menú principal........................(e)""")
            opcion_del_menu_mas_vendidos_y_rezagados = input("Seleccione una opción del menú (a / b / c / d / e): ")
            if opcion_del_menu_mas_vendidos_y_rezagados == "a":
                print("""
-------------------------------------------------------
              
 P R O D U C T O S  C O N  M A Y O R E S  V E N T A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                #Ordena en forma descendente las Ventas del 2020
                ventas_productos.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos anuales
                print("""
-------------------------------------------------------
               Ventas Año 2020
-------------------------------------------------------""")
                contador_mb = 0
                for venta1 in ventas_productos:
                  if contador_mb < 15:
                    contador_mb_imprimir = contador_mb + 1
                    print(f"{contador_mb_imprimir}.- El producto: {venta1[1]}, tiene: {venta1[2]} ventas.")
                    contador_mb +=1
                
                #Ordena en forma descendente las Ventas del 01/2020
                ventas_productosE.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Enero
                print("""
-------------------------------------------------------
              Ventas Enero 2020
-------------------------------------------------------""")
                contador_mbE = 0
                for ventaE in ventas_productosE:
                  if contador_mbE < 10:
                    contador_mbE_imprimir = contador_mbE + 1
                    print(f"{contador_mbE_imprimir}.- El producto: {ventaE[1]}, tiene: {ventaE[2]} ventas.")
                    contador_mbE += 1

                #Ordena en forma descendente las Ventas del 02/2020
                ventas_productosFeb.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Febrero
                print("""
-------------------------------------------------------
              Ventas Febrero 2020
-------------------------------------------------------""")
                contador_mbFeb = 0
                for ventaFeb in ventas_productosFeb:
                  if contador_mbFeb < 10:
                    contador_mbFeb_imprimir = contador_mbFeb + 1
                    print(f"{contador_mbFeb_imprimir}.- El producto: {ventaFeb[1]}, tiene: {ventaFeb[2]} ventas.")
                    contador_mbFeb += 1

                #Ordena en forma descendente las Ventas del 03/2020
                ventas_productosMar.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Marzo
                print("""
-------------------------------------------------------
             Ventas Marzo 2020
-------------------------------------------------------""")
                contador_mbMar = 0
                for ventaMar in ventas_productosMar:
                  if contador_mbMar < 10:
                    contador_mbMar_imprimir = contador_mbMar + 1
                    print(f"{contador_mbMar_imprimir}.- El producto: {ventaMar[1]}, tiene: {ventaMar[2]} ventas.")
                    contador_mbMar += 1

                #Ordena en forma descendente las Ventas del 04/2020
                ventas_productosAbr.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Abril
                print("""
-------------------------------------------------------
              Ventas Abril 2020
-------------------------------------------------------""")
                contador_mbAbr = 0
                for ventaAbr in ventas_productosAbr:
                  if contador_mbAbr < 10:
                    contador_mbAbr_imprimir = contador_mbAbr + 1
                    print(f"{contador_mbAbr_imprimir}.- El producto: {ventaAbr[1]}, tiene: {ventaAbr[2]} ventas.")
                    contador_mbAbr += 1

                #Ordena en forma descendente las Ventas del 05/2020
                ventas_productosMay.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Mayo
                print("""
-------------------------------------------------------
                Ventas Mayo 2020
-------------------------------------------------------""")
                contador_mbMay = 0
                for ventaMay in ventas_productosMay:
                  if contador_mbMay < 10:
                    contador_mbMay_imprimir = contador_mbMay + 1
                    print(f"{contador_mbMay_imprimir}.- El producto: {ventaMay[1]}, tiene: {ventaMay[2]} ventas.")
                    contador_mbMay += 1

                #Ordena en forma descendente las Ventas del 06/2020
                ventas_productosJun.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Junio
                print("""
-------------------------------------------------------
              Ventas Junio 2020
-------------------------------------------------------""")
                contador_mbJun = 0
                for ventaJun in ventas_productosJun:
                  if contador_mbJun < 10:
                    contador_mbJun_imprimir = contador_mbJun + 1
                    print(f"{contador_mbJun_imprimir}.- El producto: {ventaJun[1]}, tiene: {ventaJun[2]} ventas.")
                    contador_mbJun += 1

                #Ordena en forma descendente las Ventas del 07/2020
                ventas_productosJul.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Julio
                print("""
-------------------------------------------------------
              Ventas Julio 2020
-------------------------------------------------------""")
                contador_mbJul = 0
                for ventaJul in ventas_productosJul:
                  if contador_mbJul < 10:
                    contador_mbJul_imprimir = contador_mbJul + 1
                    print(f"{contador_mbJul_imprimir}.- El producto: {ventaJul[1]}, tiene: {ventaJul[2]} ventas.")
                    contador_mbJul += 1

                #Ordena en forma descendente las Ventas del 08/2020
                ventas_productosAgo.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Agosto
                print("""
-------------------------------------------------------
              Ventas Agosto 2020
-------------------------------------------------------""")
                contador_mbAgo = 0
                for ventaAgo in ventas_productosAgo:
                  if contador_mbAgo < 10:
                    contador_mbAgo_imprimir = contador_mbAgo + 1
                    print(f"{contador_mbAgo_imprimir}.- El producto: {ventaAgo[1]}, tiene: {ventaAgo[2]} ventas.")
                    contador_mbAgo += 1

                #Ordena en forma descendente las Ventas del 09/2020
                ventas_productosSep.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Septiembre
                print("""
-------------------------------------------------------
              Ventas Septiembre 2020
-------------------------------------------------------""")
                contador_mbSep = 0
                for ventaSep in ventas_productosSep:
                  if contador_mbSep < 10:
                    contador_mbSep_imprimir = contador_mbSep + 1
                    print(f"{contador_mbSep_imprimir}.- El producto: {ventaSep[1]}, tiene: {ventaSep[2]} ventas.")
                    contador_mbSep += 1

                #Ordena en forma descendente las Ventas del 10/2020
                ventas_productosOct.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Octubre
                print("""
-------------------------------------------------------
              Ventas Octubre 2020
-------------------------------------------------------""")
                contador_mbOct = 0
                for ventaOct in ventas_productosOct:
                  if contador_mbOct < 10:
                    contador_mbOct_imprimir = contador_mbOct + 1
                    print(f"{contador_mbOct_imprimir}.- El producto: {ventaOct[1]}, tiene: {ventaOct[2]} ventas.")
                    contador_mbOct += 1

                #Ordena en forma descendente las Ventas del 11/2020
                ventas_productosNov.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Noviembre
                print("""
-------------------------------------------------------
              Ventas Noviembre 2020
-------------------------------------------------------""")
                contador_mbNov = 0
                for ventaNov in ventas_productosNov:
                  if contador_mbNov < 10:
                    contador_mbNov_imprimir = contador_mbNov + 1
                    print(f"{contador_mbNov_imprimir}.- El producto: {ventaNov[1]}, tiene: {ventaNov[2]} ventas.")
                    contador_mbNov += 1

                #Ordena en forma descendente las Ventas del 12/2020
                ventas_productosDic.sort(key=lambda x:x[2], reverse = True)

                #Imprime los más vendidos Diciembre
                print("""
-------------------------------------------------------
              Ventas Diciembre 2020
-------------------------------------------------------""")
                contador_mbDic = 0
                for ventaDic in ventas_productosDic:
                  if contador_mbDic < 10:
                    contador_mbDic_imprimir = contador_mbDic + 1
                    print(f"{contador_mbDic_imprimir}.- El producto: {ventaDic[1]}, tiene: {ventaDic[2]} ventas.")
                    contador_mbDic += 1




                mostrar_menu_mas_vendidos_y_rezagados = input("Regresar al menú productos más vendidos y productos rezagados (si/no): ")
                if mostrar_menu_mas_vendidos_y_rezagados == "si":
                  continue
           
                if mostrar_menu_mas_vendidos_y_rezagados == "no":
                  continue

                elif mostrar_menu_mas_vendidos_y_rezagados != "si" and mostrar_menu_mas_vendidos_y_rezagados != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal = "si"
                  continue
                

            if opcion_del_menu_mas_vendidos_y_rezagados == "b":
                print("""
-------------------------------------------------------
              
               P R O D U C T O S  C O N  
           M A Y O R E S  B U S Q U E D A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                busquedas.sort(key=lambda x:x[1], reverse=True)

                contador_mb = 0
                for busqueda in busquedas:
                  if contador_mb < 20:
                    contador_mb_imprimir = contador_mb + 1
                    print(f"{contador_mb_imprimir}.- El producto: {busqueda[0]}, tiene: {busqueda[1]} búsquedas. ")
                    contador_mb +=1
                
                mostrar_menu_mas_vendidos_y_rezagados = input("Regresar al menú productos más vendidos y productos rezagados (si/no): ")
                if mostrar_menu_mas_vendidos_y_rezagados == "si":
                  continue

                if mostrar_menu_mas_vendidos_y_rezagados == "no":
                  print("Regresando al menú principal...")
                  continue
                elif mostrar_menu_mas_vendidos_y_rezagados != "si" and mostrar_menu_mas_vendidos_y_rezagados != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal = "si"
                  continue

            if opcion_del_menu_mas_vendidos_y_rezagados == "c":
                print("""
-------------------------------------------------------
              
          L I S T A D O  P O R  C A T E G O R I A  
             C O N  M E N O R E S  V E N T A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                ventas_productos.sort(key=lambda x:x[2])
                #Imprime ascendente
                contador_mv = 0
                for venta1 in ventas_productos:
                  if contador_mv < 30:
                    contador_mv_imprimir = contador_mv + 1
                    print(f"{contador_mv_imprimir}.- El producto: {venta1[1]}, tiene: {venta1[2]} ventas.")
                    contador_mv += 1



                mostrar_menu_mas_vendidos_y_rezagados = input("Regresar al menú productos más vendidos y productos rezagados (si/no): ")
                if mostrar_menu_mas_vendidos_y_rezagados == "si":
                  continue

                if mostrar_menu_mas_vendidos_y_rezagados == "no":
                  print("Regresando al menú principal...")
                  continue
                elif mostrar_menu_mas_vendidos_y_rezagados != "si" and mostrar_menu_mas_vendidos_y_rezagados != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal = "si"
                  continue

            if opcion_del_menu_mas_vendidos_y_rezagados == "d":
                print("""
-------------------------------------------------------
              
          L I S T A D O  P O R  C A T E G O R I A  
          C O N  M E N O R E S  B U S Q U E D A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                busquedas.sort(key=lambda x:x[1])

                contador_mb1 = 0
                for busqueda in busquedas:
                  if contador_mb1 < 20:
                    contador_mb1_imprimir = contador_mb1 + 1 
                    print(f"{contador_mb1_imprimir}.- El producto: {busqueda[0]}, tiene: {busqueda[1]} búsquedas. ")
                    contador_mb1 += 1


                mostrar_menu_mas_vendidos_y_rezagados = input("Regresar al menú productos más vendidos y productos rezagados (si/no): ")
                if mostrar_menu_mas_vendidos_y_rezagados == "si":
                  continue

                if mostrar_menu_mas_vendidos_y_rezagados == "no":
                  print("Regresando al menú principal...")
                  continue

                elif mostrar_menu_mas_vendidos_y_rezagados != "si" and mostrar_menu_mas_vendidos_y_rezagados != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal ="si"
                  continue

            if opcion_del_menu_mas_vendidos_y_rezagados == "e":
                print("Regresando al menú principal...")
                break
            
            if opcion_del_menu_mas_vendidos_y_rezagados != "a" and opcion_del_menu_mas_vendidos_y_rezagados != "b" and opcion_del_menu_mas_vendidos_y_rezagados != "c" and opcion_del_menu_mas_vendidos_y_rezagados != "d" and opcion_del_menu_mas_vendidos_y_rezagados != "si":
                print("Opción no válida")
                

        
                mostrar_menu_principal = input("Regresar al menú principal (si/no): ")
        if mostrar_menu_principal == "no": #Si el usuario desea salir del sistema.
            print("Saliendo del sistema.")
            break #Termina la ejecución del sistema.
      
        elif mostrar_menu_principal != "si" and mostrar_menu_principal != "no":
            print("Opción no válida, regresando al menú principal.")
            mostrar_menu_principal = "si"

    if opcion_del_menu_principal == "B": #Sentencia para productos por reseña en el servicio.
        opcion_del_menu_pprs = "m" #Opción del menú productos por reseña en el servicio
        mostrar_menu_pprs = "si" #pprs es productos por reseña en el servicio
        while mostrar_menu_pprs == "si":
            print("""
-------------------------------------------------------
              
                     M  E  N  U    
              P R O D U C T O S  P O R  
      R E S E Ñ A  E N  E L  S E R V I C I O     
                  
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------
Listado de productos con mejores reseñas..........(m)
Listado de productos con peores reseñas   ........(p)
Regresar al menú principal........................(e)""")

            opcion_del_menu_pprs = input("Seleccione una opción del menú (m / p / e): ")

            if opcion_del_menu_pprs == "m":
                print("""
-------------------------------------------------------
              
        L I S T A D O  D E  P R O D U C T O S   
         C O N  M E J O R E S  R E S E Ñ A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                mejoresR=[]
                for product in lifestore_products:
                  for sale_dev in sales_dev:
                    if product[0] == sale_dev[1] and sale_dev[2] == 5:
                      mejoresR.append(product[1])

                
                
                mejores = set(mejoresR)
                
                for mejor in mejores:
                  print(mejor)
                  print(" ")
                
              
                 

                mostrar_menu_pprs = input("Regresar al menú productos por reseña en el servicio (si/no): ")
                if mostrar_menu_pprs == "si":
                  continue

                if mostrar_menu_pprs == "no":
                  continue
          
                elif mostrar_menu_pprs != "si" and mostrar_menu_pprs != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal = "si"
                  continue

            if opcion_del_menu_pprs == "p":
                print("""
-------------------------------------------------------
              
        L I S T A D O  D E  P R O D U C T O S   
          C O N  P E O R E S  R E S E Ñ A S  
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
                peoresR=[]
                for product in lifestore_products:
                  for sale_dev in sales_dev:
                    if product[0] == sale_dev[1] and sale_dev[2] == 1:
                      peoresR.append(product[1])

                
                peores = set(peoresR)
                for peor in peores:
                  print(peor)
                  print(" ")


                mostrar_menu_pprs = input("Regresar al menú productos por reseña en el servicio (si/no): ")
            
                if mostrar_menu_pprs == "si":
                  continue
        
                if mostrar_menu_pprs == "no":
                  print("Regreseando al menú principal...")
                  continue
        
                elif mostrar_menu_pprs != "si" and mostrar_menu_pprs != "no":
                  print("Opción no válida, regresando al menú principal.")
                  mostrar_menu_principal = "si"
                  continue
      
            if opcion_del_menu_pprs == "e":
                print("Regresando al menú principal...")
                break
      
            if opcion_del_menu_pprs != "m" and opcion_del_menu_pprs != "p" and opcion_del_menu_pprs != "si":
                print("Opción no válida")
      



                mostrar_menu_principal = input("Regresar al menú principal (si/no): ")
        if mostrar_menu_principal == "no": #Si el usuario desea salir del sistema.
            print("Saliendo del sistema.")
            break #Termina la ejecución del sistema.
      
        elif mostrar_menu_principal != "si" and mostrar_menu_principal != "no":
            print("Opción no válida, regresando al menú principal.")
            mostrar_menu_principal = "si"

    if opcion_del_menu_principal == "C": #Sentencia para total de ingresos y ventas promedio.
      print("""
-------------------------------------------------------
              
          T O T A L  D E  I N G R E S O S   
          Y  V E N T A S  P R O M E D I O   
     
<<<<<<<<<<<<<<<<<< L i f e S t o r e >>>>>>>>>>>>>>>>>>

-------------------------------------------------------""")
      print("""
-------------------------------------------------------
      Total de ingresos mensuales
-------------------------------------------------------""")
      ingreso_enero_imprimir = str(ingreso_enero)
      print("Total de ingreso Enero: $" + ingreso_enero_imprimir)
      
      ingreso_febrero_imprimir = str(ingreso_febrero)
      print("Total de ingreso Febrero: $" + ingreso_febrero_imprimir)

      ingreso_marzo_imprimir = str(ingreso_marzo)
      print("Total de ingreso Marzo: $" + ingreso_marzo_imprimir)
      
      ingreso_abril_imprimir = str(ingreso_abril)
      print("Total de ingreso Abril: $" + ingreso_abril_imprimir)

      ingreso_mayo_imprimir = str(ingreso_mayo)
      print("Total de ingreso Mayo: $" + ingreso_mayo_imprimir)
      
      ingreso_junio_imprimir = str(ingreso_junio)
      print("Total de ingreso Junio: $" + ingreso_junio_imprimir)

      ingreso_julio_imprimir = str(ingreso_julio)
      print("Total de ingreso Julio: $" + ingreso_julio_imprimir)
      
      ingreso_agosto_imprimir = str(ingreso_agosto)
      print("Total de ingreso Agosto: $" + ingreso_agosto_imprimir)      

      ingreso_septiembre_imprimir = str(ingreso_septiembre)
      print("Total de ingreso Septiembre: $" + ingreso_septiembre_imprimir)
      
      ingreso_octubre_imprimir = str(ingreso_octubre)
      print("Total de ingreso Octubre: $" + ingreso_octubre_imprimir)

      ingreso_noviembre_imprimir = str(ingreso_noviembre)
      print("Total de ingreso Noviembre: $" + ingreso_noviembre_imprimir)
      
      ingreso_diciembre_imprimir = str(ingreso_diciembre)
      print("Total de ingreso Diciembre: $" + ingreso_diciembre_imprimir)

      print("""
-------------------------------------------------------
      Ingreso del año 2020
-------------------------------------------------------""")
      ingreso_anual_imprimir = str(ingreso_anual)
      print("Total de ingresos anuales: $" + ingreso_anual_imprimir)

      #Total de ventas con devolución
      ventas_dev = 0
      for venta_productod in ventas_productosd:
        ventas_dev += venta_productod[2]
     
      ventas_dev_imprimir = str(ventas_dev)
      print("Cantidad de ventas anuales: " + ventas_dev_imprimir)

      ventas_dev_promedio = ventas_dev // 12
      ventas_dev_promedio_imprimir = str(ventas_dev_promedio)
      print("Cantidad de ventas promedio:" + ventas_dev_promedio_imprimir)
      
      mostrar_menu_principal = input("Regresar al menú principal (si/no): ")
      if mostrar_menu_principal == "no": #Si el usuario desea salir del sistema.
        print("Saliendo del sistema.")
        break #Termina la ejecución del sistema.

      elif mostrar_menu_principal !="si" and mostrar_menu_principal != "no": #Sentencia para cuando el usuario ingresa una opción no válida.
        print("Opción no válida, regresando al menú principal.")
      mostrar_menu_principal = "si"
    
    if opcion_del_menu_principal == "D": #Sentencia para cuando el usuario desea salir del sistema.
      print("Saliendo del sistema.")
      break #Termina la ejecución del sistema.

    if opcion_del_menu_principal != "A" and opcion_del_menu_principal != "B" and opcion_del_menu_principal != "C" and opcion_del_menu_principal != "D" and opcion_del_menu_principal != "si": #Sentencia para cuando el usuario ingresa una opción no válida en el sistema.
      print("Opción no valida, regresando al menú principal.")
      mostrar_menu_principal = "si"








else: #Sentencia para cuando el usuario ingresa incorrectos tres veces los datos del login.
  print("""Los datos de usuario son incorrectos. 
Acceso Denegado.""")